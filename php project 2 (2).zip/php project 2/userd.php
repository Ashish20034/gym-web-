<?php
session_start();

// Ensure the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo "Please log in first.";
    exit();
}

// Check if the session variable 'user_email' is set
if (!isset($_SESSION['user_email'])) {
    echo "User not found!";
    exit();
}

// Retrieve the user's email from the session
$user_email = $_SESSION['user_email'];

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user data using the email stored in the session
$stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found!";
    exit();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #e0e0e0;
        }
        h2 {
            color: #333;
        }
        p {
            color: #555;
        }
        .user-info {
            background: linear-gradient(145deg, #ffffff, #e6e6e6);
            padding: 20px;
            border-radius: 8px;
            box-shadow: 8px 8px 15px rgba(0, 0, 0, 0.2), -8px -8px 15px rgba(255, 255, 255, 0.7);
            margin-bottom: 20px;
        }
        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: white;
            background-color: #4CAF50;
            padding: 10px 15px;
            border-radius: 5px;
        }
        a:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <h2>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</h2>
    <div class="user-info">
        <p>Email: <?php echo htmlspecialchars($user['email']); ?></p>
        <p>Phone: <?php echo htmlspecialchars($user['phone']); ?></p>
        <p>Gender: <?php echo htmlspecialchars($user['gender']); ?></p>
        <p>Your Role: User</p>
    </div>

    <a href="logout3.php">Logout</a>
</body>
</html>
