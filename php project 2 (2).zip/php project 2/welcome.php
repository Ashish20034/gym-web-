<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: loginfinalphp.php');
    exit;
}

// Display welcome message
$user_name = htmlspecialchars($_SESSION['user_name']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Training - Gym Management</title>
    <style>
        /* General Styles */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            background-color: #f5f5f5;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        header h1 {
            margin: 0;
            font-size: 2.5rem;
        }

        .personal-training {
            padding: 40px;
            text-align: center;
        }

        .personal-training h2 {
            font-size: 2rem;
            margin-bottom: 20px;
        }

        .personal-training p {
            font-size: 1.2rem;
            margin-bottom: 40px;
            max-width: 800px;
            margin: 0 auto;
        }

        .trainer-cards {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        .trainer-card {
            background: linear-gradient(to bottom, #fff, #f4f4f4);
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin: 15px;
            overflow: hidden;
            width: 320px;
            transition: transform 0.3s, box-shadow 0.3s;
            position: relative;
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            padding: 20px;
        }

        .trainer-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.2);
        }

        .trainer-image {
            position: relative;
            width: 100%;
        }

        .trainer-image img {
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 15px;
        }

        .trainer-card h3 {
            font-size: 1.5rem;
            margin: 10px 0;
        }

        .trainer-card p {
            font-size: 1rem;
            margin-bottom: 15px;
        }

        .trainer-card button {
            background-color: #3498db;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        .trainer-card button:hover {
            background-color: #2980b9;
        }

        .footer {
            background-color: #333;
            color: white;
            padding: 20px;
            text-align: center;
            margin-top: 40px;
        }

        .footer p {
            margin: 5px 0;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fff;
            margin: 5% auto;
            padding: 20px;
            border-radius: 10px;
            width: 80%;
            max-width: 600px;
        }

        .modal-content h2 {
            margin-top: 0;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        /* Form Styles */
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        label {
            margin: 5px 0;
            font-weight: bold;
        }

        input, textarea, select {
            margin-bottom: 10px;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1em;
        }

        button {
            padding: 12px;
            border: none;
            border-radius: 5px;
            background-color: #3498db;
            color: #fff;
            cursor: pointer;
            font-size: 1em;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #2980b9;
        }

        @media (max-width: 768px) {
            .trainer-cards {
                flex-direction: column;
                align-items: center;
            }

            .trainer-card {
                width: 90%;
                max-width: 400px;
            }
        }

        /* Accessibility */
        input:focus, textarea:focus, select:focus {
            outline: 2px solid #3498db;
        }
 


 {
      font-family: sans-serif;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
    }

    .container {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
    }

    .card-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
    }

    .card {
      background-color: #fff;
      border-radius: 10px;
      padding: 30px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      width: 300px;
      text-align: center;
    }

    .card img {
      width: 100%;
      height: 150px;
      object-fit: cover;
      border-radius: 10px 10px 0 0;
    }

    .card h2 {
      margin-bottom: 10px;
    }

    .card p {
      margin-bottom: 20px;
    }

    .button {
      background-color: #4CAF50;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    </style>
</head>
<body>

    <header>
        <h1>Welcome, <?php echo $user_name; ?>! welcome to your dashboard</h1>
    </header>

    <div class="personal-training">
        <h2>Personal Training</h2>
        <p>Get personalized training sessions with our expert trainers to achieve your fitness goals.</p>
        <div class="trainer-cards">
            <div class="trainer-card">
                <div class="trainer-image">
                    <img src="Screenshot 2024-09-17 193708.png" alt="Trainer 1">
                </div>
                <h3>Trainer 1</h3>
                <p>Experienced trainer specializing in strength training and weight loss.</p>
                            </div>
            <div class="trainer-card">
                <div class="trainer-image">
                    <img src="Screenshot 2024-09-18 222114.png" alt="Trainer 2">
                </div>
                <h3>Trainer 2</h3>
                <p>Certified trainer with expertise in cardio and endurance training.</p>
                
            </div>
            <div class="trainer-card">
                <div class="trainer-image">
                    <img src="Screenshot 2024-09-18 222409.png" alt="Trainer 3">
                </div>
                <h3>Trainer 3</h3>
                <p>Specialist in yoga and flexibility training.</p>
                            </div>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2024 Gym Management Website. All rights reserved.</p>
        <p>123 Fitness St, Muscle City, ST 45678 | Phone: (123) 456-7890</p>
    </div>

    <script>
        // Placeholder function for booking a session
        function openBookingForm(trainer) {
            alert('You have selected ' + trainer + ' for booking a session.');
        }
    </script>



<div class="container">
    <div class="header">
      <h1>Group Classes</h1>
      <p>Choose from our variety of group fitness classes to find the one that suits you best.</p>
    </div>

    <div class="card-container">
      <div class="card">
        <img src="Screenshot 2024-09-18 222620.png" alt="Zumba Class">
        <h2>Zumba</h2>
        <p>Get moving and grooving with our high-energy Zumba classes.</p>
        
      </div>

      <div class="card">
        <img src="Screenshot 2024-09-18 222935.png" alt="Spin Class">
        <h2>Spin Class</h2>
        <p>Challenge yourself with our intense spin classes.</p>
              </div>

      <div class="card">
        <img src="Screenshot 2024-09-18 223111.png" alt="Yoga Class">
        <h2>Yoga</h2>
        <p>Improve your flexibility and balance with our yoga classes.</p>
        
      </div>

      <div class="card">
        <img src="Screenshot 2024-09-18 223248.png" alt="Pilates Class">
        <h2>Pilates</h2>
        <p>Strengthen your core and improve your posture with our Pilates classes.</p>
       
      </div>
    </div>
  </div>

</body>
</html>