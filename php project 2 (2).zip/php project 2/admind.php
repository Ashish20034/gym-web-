<?php
// Start the session
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.php"); // Redirect to the login page if not logged in
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch admin details (for display)
$email = 'ashishshinde2005@gmail.com'; // Use your admin email for testing
$stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
if ($stmt === false) {
    die("Error preparing statement for admin details: " . $conn->error);
}
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

// Fetch all users with payment details (using email as join key)
$sql = "
    SELECT 
        users.id AS user_id, 
        users.name AS user_name, 
        users.email AS user_email, 
        payment.payment_id, 
        payment.payment_date, 
        payment.amount, 
        payment.plan_name, 
        payment.card_last_digits, 
        payment.status 
    FROM users 
    LEFT JOIN payment ON users.email = payment.user_email
";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die("Error preparing statement for users and payments: " . $conn->error);
}
$stmt->execute();
$users_payments_result = $stmt->get_result();
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="style.css"> <!-- Link your CSS file here -->
</head>
<body>
    <div class="header">
        <h1>Welcome, Admin</h1>
        <p>Hello <?php echo htmlspecialchars($admin['username']); ?>, welcome to your dashboard.</p>
    </div>

    <div class="nav">
        <ul>
            <li><a href="home.html">Logout</a></li>
        </ul>
    </div>

    <div class="content">
     
        <h2>Users and Payments List</h2>
        <?php if ($users_payments_result->num_rows > 0) { ?>
            <table border="1" cellpadding="10" cellspacing="0">
                <thead>
                    <tr>
                        <th>User ID</th>
                        <th>User Name</th>
                        <th>User Email</th>
                        <th>Payment ID</th>
                        <th>Payment Date</th>
                        <th>Amount</th>
                        <th>Plan Name</th>
                        <th>Card Last Digits</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $users_payments_result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['user_id']); ?></td>
                            <td><?php echo htmlspecialchars(ucwords($row['user_name'])); ?></td>
                            <td><?php echo htmlspecialchars($row['user_email']); ?></td>
                            <td><?php echo htmlspecialchars($row['payment_id'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['payment_date'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['amount'] !== null ? '$' . number_format($row['amount'], 2) : 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['plan_name'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['card_last_digits'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($row['status'] ?? 'N/A'); ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No users or payments found.</p>
        <?php } ?>
    </div>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .header, .nav, .content {
            margin: 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header h1, .content h2 {
            margin: 0;
        }
        .nav ul {
            list-style-type: none;
            padding: 0;
        }
        .nav ul li {
            display: inline;
            margin-right: 10px;
        }
        .nav ul li a {
            text-decoration: none;
            color: #4CAF50;
        }
        .nav ul li a:hover {
            text-decoration: underline;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</body>
</html>
