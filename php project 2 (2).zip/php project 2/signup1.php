<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the request method is POST (form submitted)
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize the form inputs
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = $conn->real_escape_string($_POST['phone']);

    // Initialize an array to store errors
    $errors = [];

    // Validate the input
    if (strlen($name) < 3) {
        $errors[] = "Name should be at least 3 characters long.";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email format.";
    }

    if (strlen($password) < 6) {
        $errors[] = "Password should be at least 6 characters long.";
    }

    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match.";
    }

    if (!preg_match("/^[0-9]{10}$/", $phone)) {
        $errors[] = "Phone number must be 10 digits long.";
    }

    // Check if email already exists
    $email_check_query = "SELECT * FROM users WHERE email='$email' LIMIT 1";
    $result = $conn->query($email_check_query);

    // Check if the query was successful
    if ($result === false) {
        // Query failed, show error message
        $errors[] = "Error in query: " . $conn->error;
    } else {
        // If query was successful, check for existing email
        if ($result->num_rows > 0) {
            $errors[] = "Email already exists! You have already signed up.";
        }
    }

    // If there are no validation errors, proceed with registration
    if (empty($errors)) {
        // Hash the password for security
        $passwordHash = password_hash($password, PASSWORD_BCRYPT);

        // Prepare and execute the SQL query
        $stmt = $conn->prepare("INSERT INTO users (name, email, gender, password, phone) VALUES (?, ?, ?, ?, ?)");

        // Check if prepare() was successful
        if ($stmt === false) {
            // Prepare failed, show error message
            echo "Error preparing statement: " . $conn->error;
        } else {
            // Bind parameters and execute if the statement is prepared successfully
            $stmt->bind_param("sssss", $name, $email, $gender, $passwordHash, $phone);

            if ($stmt->execute()) {
                // Success message and redirect to login
                echo "Registration successful! <a href='loginfinal1.html'>Login here</a>";
            } else {
                // Show error if the statement execution failed
                echo "Error: " . $stmt->error;
            }

            // Close the prepared statement
            $stmt->close();
        }
    } else {
        // If there are validation errors, display them
        foreach ($errors as $error) {
            echo "<p style='color:red;'>$error</p>";
        }
    }
}

// Close the database connection
$conn->close();
?>
