<?php
// Database connection
$host = 'localhost';
$username = 'root'; // Replace with your MySQL username
$password = '';     // Replace with your MySQL password
$dbname = 'gym'; // Replace with your database name

// Create a new mysqli object for the connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect the form data
$user_email = $_POST['email'];
$card_number = $_POST['card-number'];
$expiration_date = $_POST['expiration-date'];
$cvv = $_POST['cvv'];
$plan_name = $_POST['plan-name'];
$amount = $_POST['amount'];

// Get the last 4 digits of the card number (for security purposes)
$card_last_digits = substr($card_number, -4);

// Prepare the SQL query to insert the payment information
$sql = "INSERT INTO payments (user_email, plan_name, card_last_digits, amount, status)
        VALUES (?, ?, ?, ?, 'Completed')";

// Prepare and bind the SQL statement
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssd", $user_email, $plan_name, $card_last_digits, $amount);

// Execute the SQL statement
if ($stmt->execute()) {
    echo "Payment successfully processed!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
