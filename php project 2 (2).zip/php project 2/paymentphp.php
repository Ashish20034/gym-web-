<?php
// Database connection
$host = 'localhost';
$username = 'root'; // Replace with your MySQL username
$password = '';     // Replace with your MySQL password
$dbname = 'gym';    // Replace with your database name

// Create a new mysqli object for the connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check if the connection is successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect the form data and perform basic validation
$user_email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
$card_number = filter_var($_POST['card-number'], FILTER_SANITIZE_STRING);
$expiration_date = filter_var($_POST['expiration-date'], FILTER_SANITIZE_STRING);
$cvv = filter_var($_POST['cvv'], FILTER_SANITIZE_STRING);
$plan_name = filter_var($_POST['plan-name'], FILTER_SANITIZE_STRING);
$amount = filter_var($_POST['amount'], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

// Validate email
if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format");
}

// Validate amount
if (!is_numeric($amount) || $amount <= 0) {
    die("Invalid amount");
}

// Get the last 4 digits of the card number (for security purposes)
$card_last_digits = substr($card_number, -4);

// Prepare the SQL query to insert the payment information
$sql = "INSERT INTO payment (user_email, plan_name, card_last_digits, amount, status, payment_date) 
        VALUES (?, ?, ?, ?, 'Completed', NOW())";

// Prepare and bind the SQL statement
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Prepare failed: " . $conn->error); // Error handling for failed prepare()
}

// Bind parameters
if (!$stmt->bind_param("sssd", $user_email, $plan_name, $card_last_digits, $amount)) {
    die("Bind failed: " . $stmt->error); // Error handling for failed bind_param()
}

// Execute the SQL statement
if ($stmt->execute()) {
    echo "Payment successfully processed!";
} else {
    echo "Error executing query: " . $stmt->error;
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
