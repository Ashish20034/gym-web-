<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start a session
session_start();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $loginType = $_POST['loginType']; // Check if user wants to login as user or admin

    // Validate input
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    if ($loginType == 'admin') {
        // Query the database for the admin
        $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            echo "Error in SQL query: " . $conn->error;
            exit;
        }

        if ($result->num_rows > 0) {
            // Fetch admin data if the email exists
            $admin = $result->fetch_assoc();

            // Check if the password is correct
            if (password_verify($password, $admin['password'])) {
                // Set session variables for logged-in admin state
                $_SESSION['logged_in'] = true;
                $_SESSION['user_name'] = 'Admin';
                $_SESSION['role'] = 'admin';

                // Redirect to admin dashboard
                header("Location: admind.php");
                exit;
            } else {
                echo "<p style='color:red;'>Invalid password for admin!</p>";
                exit;
            }
        } else {
            echo "<p style='color:red;'>Admin not found!</p>";
            exit;
        }
    } else {
        // Handle user login
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            echo "Error in SQL query: " . $conn->error;
            exit;
        }

        if ($result->num_rows > 0) {
            // Fetch user data if the email exists
            $user = $result->fetch_assoc();

            // Check if the password is correct
            if (password_verify($password, $user['password'])) {
                // Set session variables for logged-in state
                $_SESSION['logged_in'] = true;
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['role'] = $user['role'];

                // Check if the user has a payment record
                $stmt_payment = $conn->prepare("SELECT * FROM payment WHERE user_email = ?");
                $stmt_payment->bind_param("s", $email);
                $stmt_payment->execute();
                $payment_result = $stmt_payment->get_result();

                // Check if the payment record exists
                if ($payment_result->num_rows > 0) {
                    // Redirect to welcome dashboard if the payment record exists
                    header("Location: welcome.php");
                    exit;
                } else {
                    // Redirect to the payment page if no payment record is found
                    header("Location: loginfinal2.php");
                    exit;
                }
            } else {
                echo "<p style='color:red;'>Invalid password!</p>";
                exit;
            }
        } else {
            echo "<p style='color:red;'>User not found! Please sign up first.</p>";
            exit;
        }
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>


<html>
<head>
    <style>
        /* Rest of the styles remain the same */
    </style>
</head>
<body>
    <div class="header">
        <h1>Alpha Gym</h1>
    </div>

    <div class="hero">
        <h1><span class="auto-input"></span></h1>
        <p>Get fit, feel great, and reach your goals with our state-of-the-art facilities and expert trainers.</p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script>
        let typed = new Typed(".auto-input", {
            strings: ["Welcome to our gym"],
            typeSpeed: 100,
            backSpeed: 100,
            loop: true
        });
    </script>

    <div class="payment-plans">
        <div class="payment-plan">
            <h2>Monthly Plan</h2>
            <p>2000/month - Access to gym equipment and group classes.</p>
            <button onclick="selectPlan('Monthly Plan', 2000)">Select Plan</button>
        </div>

        <div class="payment-plan">
            <h2>Yearly Plan</h2>
            <p>12000 - Includes personal training, group classes, and nutrition plans.</p>
            <button onclick="selectPlan('Yearly Plan', 12000)">Select Plan</button>
        </div>
    </div>

    <script>
        // Updated function to handle both plan and amount
        function selectPlan(plan, amount) {
            window.location.href = 'paymentfix.html?plan=' + plan + '&amount=' + amount;
        }
    </script>

    <div class="footer">
        <p>&copy; 2024 Gym Management Website. All rights reserved.</p>
        <p>123 Fitness St, Muscle City, ST 45678 | Phone: (123) 456-7890</p>
    </div>
</body>
</html>
