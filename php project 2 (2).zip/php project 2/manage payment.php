<?php
// Start the session
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['role'] !== 'admin') {
    header("Location: loginfinalphp.php"); // Redirect to the login page if not logged in
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $monthly_price = $_POST['monthly_price'];
    $yearly_price = $_POST['yearly_price'];

    // Update monthly plan
    $stmt = $conn->prepare("UPDATE payment_plans SET price = ? WHERE plan_name = 'Monthly Plan'");
    $stmt->bind_param("d", $monthly_price);
    $stmt->execute();
    $stmt->close();

    // Update yearly plan
    $stmt = $conn->prepare("UPDATE payment_plans SET price = ? WHERE plan_name = 'Yearly Plan'");
    $stmt->bind_param("d", $yearly_price);
    $stmt->execute();
    $stmt->close();

    echo "<p>Prices updated successfully!</p>";
}

// Fetch current plan prices
$monthly_result = $conn->query("SELECT price FROM payment_plans WHERE plan_name = 'Monthly Plan'");
$yearly_result = $conn->query("SELECT price FROM payment_plans WHERE plan_name = 'Yearly Plan'");

$monthly_plan = $monthly_result->fetch_assoc();
$yearly_plan = $yearly_result->fetch_assoc();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Payments</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 10px;
            font-weight: bold;
        }
        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Manage Payment Plans</h2>

    <form method="post" action="managepayment.php">
        <label for="monthly_price">Monthly Plan Price:</label>
        <input type="number" step="0.01" id="monthly_price" name="monthly_price" value="<?php echo $monthly_plan['price']; ?>" required>

        <label for="yearly_price">Yearly Plan Price:</label>
        <input type="number" step="0.01" id="yearly_price" name="yearly_price" value="<?php echo $yearly_plan['price']; ?>" required>

        <button type="submit">Update Prices</button>
    </form>
</div>
<li><a href="managepayment.php">Manage Payments</a></li>

</body>
</html>
