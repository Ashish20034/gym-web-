<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
$conn = new mysqli('localhost', 'root', '', 'gym');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start a session
session_start();

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form inputs
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $loginType = $_POST['loginType']; // Check if user wants to login as user or admin

    // Validate input
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit;
    }

    if ($loginType == 'admin') {
        // Query the database for the admin
        $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            echo "Error in SQL query: " . $conn->error;
            exit;
        }

        if ($result->num_rows > 0) {
            // Fetch admin data if the email exists
            $admin = $result->fetch_assoc();

            // Check if the password is correct
            if (password_verify($password, $admin['password'])) {
                // Set session variables for logged-in admin state
                $_SESSION['logged_in'] = true;
                $_SESSION['user_name'] = 'Admin';
                $_SESSION['role'] = 'admin';

                // Fetch payment and user details
                header("Location: admind.php"); // Redirect to admin dashboard
                exit;
            } else {
                echo "<p style='color:red;'>Invalid password for admin!</p>";
                exit;
            }
        } else {
            echo "<p style='color:red;'>Admin not found!</p>";
            exit;
        }
    } else {
        // Handle user login as before
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result === false) {
            echo "Error in SQL query: " . $conn->error;
            exit;
        }

        if ($result->num_rows > 0) {
            // Fetch user data if the email exists
            $user = $result->fetch_assoc();

            // Check if the password is correct
            if (password_verify($password, $user['password'])) {
                // Set session variables for logged-in state
                $_SESSION['logged_in'] = true;
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['role'] = $user['role'];

                // Redirect based on role
                if ($user['role'] == 'user' && $loginType == 'user') {
                    echo "<h2>Welcome User, " . htmlspecialchars($user['name']) . "!</h2>";
                    // Redirect to user dashboard
                    // header("Location: user_dashboard.php");
                }
            } else {
                echo "<p style='color:red;'>Invalid password!</p>";
                exit;
            }
        } else {
            echo "<p style='color:red;'>User not found! Please sign up first.</p>";
            exit;
        }
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}
?>


<html>
<head>
<style>
	/* rest of the styles remain the same */
	
	body {
		font-family: Arial, sans-serif;
		background-color: #f0f0f0;
		background-image: url('Screenshot 2024-09-18 205708.png'); /* Add this line */
		background-size: cover; /* Add this line */
		background-position: center; /* Add this line */
	}
	
	.header {
		background-color: #333;
		color: #fff;
		padding: 20px;
		text-align: center;
		display: flex;
		justify-content: center;
		align-items: center;
	}
	
	.header h1 {
		margin: 0;
	}
	
	.hero {
		background-image: linear-gradient(to bottom, #4CAF50, #3e8e41);
		background-size: 100% 300px;
		background-position: 0% 100%;
		height: 300px;
		display: flex;
		justify-content: center;
		align-items: center;
		color: #fff;
		flex-direction: column;
	}
	
	.hero h1 {
		font-size: 48px;
		margin-bottom: 20px;
	}
	
	.hero p {
		font-size: 24px;
		margin-bottom: 40px;
	}
	
	.features {
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		padding: 40px;
	}
	
	.feature {
		background-color: #fff;
		padding: 20px;
		margin: 20px;
		border: 1px solid #ddd;
		border-radius: 10px;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		width: 250px;
		display: flex;
		flex-direction: column;
		align-items: center;
		text-align: center; /* added text-align: center */
	}
	
	.feature h2 {
		margin-top: 0;
	}
	
	.feature p {
		margin-bottom: 20px;
	}
	
	.feature button {
		background-color: #4CAF50;
		color: #fff;
		padding: 10px 20px;
		border: none;
		border-radius: 5px;
		cursor: pointer;
	}
	
	.feature button:hover {
		background-color: #3e8e41;
	}
	
	.hero::before {
		content: "";
		background-image: url('https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.pexels.com%2Fsearch%2Fgym%2F&psig=AOvVaw10XrDf0UKDu4szjJgl4WCg&ust=1727771729747000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCIij07qh6ogDFQAAAAAdAAAAABAE');
		background-size: cover;
		background-position: center;
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 300px;
		z-index: -1;
	}
	
	.feature:hover {
		box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
	}
	
	.payment-plans {
		display: flex;
		flex-wrap: wrap;
		justify-content: center;
		padding: 40px;
	}
	
	.payment-plan {
		background-color: #fff;
		padding: 20px;
		margin: 20px;
		border: 1px solid #ddd;
		border-radius: 10px;
		box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
		width: 250px;
		display: flex;
		flex-direction: column;
		align-items: center;
		text-align: center;
	}
	
	.payment-plan h2 {
		margin-top: 0;
	}
	
	.payment-plan p {
		margin-bottom: 20px;
	}
	
	.payment-plan button {
		background-color: #4CAF50;
		color: #fff;
		padding: 10px 20px;
		border: none;
		border-radius: 5px;
		cursor: pointer;
	}
	
	.payment-plan button:hover {
		background-color: #3e8e41;
	}
	
	.footer {
		background-color: #333;
		color: #fff;
		text-align: center;
		padding: 20px;
		margin-top: 20px;
	}
	
	.bg-images {
		position: relative;
		width: 100%;
		height: 300px; /* adjust the height to your liking */
		overflow: hidden;
	}
	
	.bg-image-1, .bg-image-2 {
		position: absolute;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		animation: scroll 30s linear infinite;
	}
	
	.bg-image-1 {
		animation-delay: 0s;
	}
	
	.bg-image-2 {
		animation-delay: 15s;
	}
	
	@keyframes scroll {
		0% {
			transform: translateX(0);
		}
		100% {
			transform: translateX(-100%);
		}
	}
</style>
</head>
<body>
	<div class="header">
		<h1>Alpha Gym</h1>
	</div>
	
	<div class="hero">
		<h1><span class="auto-input"></span></h1>
		<p>Get fit, feel great, and reach your goals with our state-of-the-art facilities and expert trainers.</p>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
	<script>
		let typed = new Typed(".auto-input", {
			strings: ["Welcome to our gym"],
			typeSpeed: 100,
			backSpeed: 100,
			loop: true
		});
	</script>
	
	<div class="payment-plans">
		<div class="payment-plan">
			<h2>Monthly Plan</h2>
			<p>2000/month - Access to gym equipment and group classes.</p>
			<!-- Updated button to pass plan and amount -->
			<button onclick="selectPlan('Monthly Plan', 2000)">Select Plan</button>
		</div>

		<div class="payment-plan">
			<h2>Yearly Plan</h2>
			<p>12000 - Includes personal training, group classes, and nutrition plans.</p>
			<!-- Updated button to pass plan and amount -->
			<button onclick="selectPlan('Yearly Plan', 12000)">Select Plan</button>
		</div>
	</div>

	<script>
		// Updated function to handle both plan and amount
		function selectPlan(plan, amount) {
			window.location.href = 'paymentfix.html?plan=' + plan + '&amount=' + amount;
		}
	</script>
	
	<div class="footer">
		<p>&copy; 2024 Gym Management Website. All rights reserved.</p>
		<p>123 Fitness St, Muscle City, ST 45678 | Phone: (123) 456-7890</p>
	</div>
</body>
</html>